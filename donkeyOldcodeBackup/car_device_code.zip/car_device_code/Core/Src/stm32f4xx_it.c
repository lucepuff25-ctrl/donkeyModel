/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32f4xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f4xx_it.h"
/* USER CODE BEGIN Includes */
#include "motor_can.h"
#include "protocol.h"
#include "../../SHOU/shou_control.h"
/* USER CODE END Includes */

extern CAN_HandleTypeDef hcan1;
extern UART_HandleTypeDef huart6;
extern HCD_HandleTypeDef hhcd_USB_OTG_FS;

void NMI_Handler(void)       { while (1) {} }
void HardFault_Handler(void) { while (1) {} }
void MemManage_Handler(void) { while (1) {} }
void BusFault_Handler(void)  { while (1) {} }
void UsageFault_Handler(void){ while (1) {} }
void SVC_Handler(void)       {}
void DebugMon_Handler(void)  {}
void PendSV_Handler(void)    {}
void SysTick_Handler(void)   { HAL_IncTick(); }

void CAN1_RX0_IRQHandler(void)  { HAL_CAN_IRQHandler(&hcan1); }
void USART6_IRQHandler(void)    { HAL_UART_IRQHandler(&huart6); }
void OTG_FS_IRQHandler(void)    { HAL_HCD_IRQHandler(&hhcd_USB_OTG_FS); }

/* USER CODE BEGIN 1 */
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
    motor_can_rx_callback(hcan);
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    protocol_uart_rx_callback(huart);
}
/* USER CODE END 1 */
