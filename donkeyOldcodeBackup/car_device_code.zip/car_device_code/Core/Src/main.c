/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "can.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "motor_can.h"
#include "protocol.h"
#include "../../SHOU/shou_control.h"
#include <stdio.h>
/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
#if (CONTROL_INPUT_MODE != CONTROL_MODE_SHOU_USB_GAMEPAD)
static uint32_t debug_print_tick = 0U;
#endif
static uint32_t control_tick = 0U;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);

/* USER CODE BEGIN 0 */
/* Redirect printf to USART6 */
int fputc(int ch, FILE *f)
{
    HAL_UART_Transmit(&huart6, (uint8_t *)&ch, 1, 10);
    return ch;
}
/* USER CODE END 0 */

int main(void)
{
    HAL_Init();
    SystemClock_Config();

    MX_GPIO_Init();
    MX_USART6_UART_Init();

    /* USER CODE BEGIN 2 */
    MX_CAN1_Init();

    /* Wait for ESC power-on init */
//  HAL_Delay(2000);

    /* Recover from Bus-Off if needed */
    if (__HAL_CAN_GET_FLAG(&hcan1, CAN_FLAG_BOF))
        HAL_CAN_ResetError(&hcan1);

    motor_can_filter_init(&hcan1);
    motor_can_start(&hcan1);

#if (CONTROL_INPUT_MODE == CONTROL_MODE_SHOU_USB_GAMEPAD)
    shou_init();
#else
    protocol_init(&huart6);
#endif
    /* USER CODE END 2 */

    /* USER CODE BEGIN WHILE */
    int16_t iq[4] = {0};
    while (1)
    {
        /* USER CODE BEGIN 3 */
#if (CONTROL_INPUT_MODE == CONTROL_MODE_SHOU_USB_GAMEPAD)
        shou_poll();

        if ((HAL_GetTick() - control_tick) < 10U) {
            continue;
        }
        control_tick = HAL_GetTick();

        shou_update(iq);
#else
        protocol_update(iq);

        debug_print_tick++;
        if (debug_print_tick >= 50U) {
            debug_print_tick = 0U;
            printf("RPM1=%d RPM2=%d RPM3=%d RPM4=%d IQ1=%d IQ2=%d IQ3=%d IQ4=%d\r\n",
                   motor_data[0].speed_rpm,
                   motor_data[1].speed_rpm,
                   motor_data[2].speed_rpm,
                   motor_data[3].speed_rpm,
                   iq[0], iq[1], iq[2], iq[3]);
        }
#endif

        motor_set_current(&hcan1, iq[0], iq[1], iq[2], iq[3]);

#if (CONTROL_INPUT_MODE != CONTROL_MODE_SHOU_USB_GAMEPAD)
        HAL_Delay(10);
#endif
        /* USER CODE END 3 */
    }
}

void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    __HAL_RCC_PWR_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
    RCC_OscInitStruct.HSEState       = RCC_HSE_ON;
    RCC_OscInitStruct.PLL.PLLState   = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource  = RCC_PLLSOURCE_HSE;
    RCC_OscInitStruct.PLL.PLLM       = 6;
    RCC_OscInitStruct.PLL.PLLN       = 168;
    RCC_OscInitStruct.PLL.PLLP       = RCC_PLLP_DIV2;
    RCC_OscInitStruct.PLL.PLLQ       = 7;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) Error_Handler();

    RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                     | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK) Error_Handler();
}

void Error_Handler(void)
{
    __disable_irq();
    while (1) {}
}
