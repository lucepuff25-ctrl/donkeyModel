2026_moto\startup_stm32f427xx.o: startup_stm32f427xx.s
