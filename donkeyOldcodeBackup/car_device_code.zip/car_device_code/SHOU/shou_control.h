#ifndef __SHOU_CONTROL_H
#define __SHOU_CONTROL_H

#include "main.h"
#include <stdint.h>

void shou_init(void);
void shou_poll(void);
void shou_update(int16_t out[4]);

#endif /* __SHOU_CONTROL_H */
