#ifndef __USBH_HID_GAMEPAD_H
#define __USBH_HID_GAMEPAD_H

#include "usbh_core.h"

//有线ps2手柄设备标识符
//#define Wired_PS2_VID 0x0810
//#define Wired_PS2_PID 0x0001

//
#define Xbox360_VID 0x045E
#define Xbox360_PID 0x028E

//无线ps2手柄PC模式设备标识符
#define Wireless_PC_PS2_VID 0x0079
#define Wireless_PC_PS2_PID 0x0126

extern USBH_ClassTypeDef GamePad_HID_Class;
extern USBH_ClassTypeDef GamePad_NonStdHID_Class;

USBH_StatusTypeDef USBH_HID_PS2_Decode(USBH_HandleTypeDef *phost);


#endif /* __USBH_HID_GAMEPAD_H */
