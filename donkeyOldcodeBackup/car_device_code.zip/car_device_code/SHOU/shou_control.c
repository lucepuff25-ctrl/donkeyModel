#include "shou_control.h"

#include "bsp_gamepad.h"
#include "usb_host.h"
#include "usbh_hid_GamePad.h"
#include "xbox360_gamepad.h"
#include <stdio.h>

#define SHOU_AXIS_CENTER   127.0f
#define SHOU_AXIS_RANGE    127.0f
#define SHOU_AXIS_DEADBAND 0.08f
#define SHOU_MAX_CURRENT   5000.0f
#define SHOU_RAMP_STEP     250.0f
#define SHOU_TURN_GAIN     0.85f
#define SHOU_PRINT_DIV     10U

static float shou_left_current = 0.0f;
static float shou_right_current = 0.0f;
static uint32_t shou_print_tick = 0U;

static float shou_clampf(float value, float min_value, float max_value)
{
    if (value < min_value) return min_value;
    if (value > max_value) return max_value;
    return value;
}

static float shou_apply_deadband(float value)
{
    if (value > -SHOU_AXIS_DEADBAND && value < SHOU_AXIS_DEADBAND)
        return 0.0f;

    if (value > 0.0f)
        return (value - SHOU_AXIS_DEADBAND) / (1.0f - SHOU_AXIS_DEADBAND);

    return (value + SHOU_AXIS_DEADBAND) / (1.0f - SHOU_AXIS_DEADBAND);
}

static float shou_axis_signed(uint8_t raw, uint8_t invert)
{
    float value = ((float)raw - SHOU_AXIS_CENTER) / SHOU_AXIS_RANGE;
    value = shou_clampf(value, -1.0f, 1.0f);
    if (invert) {
        value = -value;
    }
    return shou_apply_deadband(value);
}

static void shou_reset_outputs(int16_t out[4])
{
    shou_left_current = 0.0f;
    shou_right_current = 0.0f;
    out[0] = 0;
    out[1] = 0;
    out[2] = 0;
    out[3] = 0;
}

void shou_init(void)
{
    GamePadInterface = &GamePadDefalut;
    USB_GamePad_PullOutCallback();
    MX_USB_HOST_Init();
}

void shou_poll(void)
{
    MX_USB_HOST_Process();
}

void USBH_HID_EventCallback(USBH_HandleTypeDef *phost)
{
    (void)USBH_HID_PS2_Decode(phost);
}

void Xbox360GamePad_KeyEvent_Callback(uint8_t keyid, GamePadKeyEventType_t event)
{
    if (event != GamePadKeyEvent_SINGLECLICK) {
        return;
    }

    if (keyid == Xbox360KEY_Menu && GamePadInterface != NULL && GamePadInterface->SetVibration != NULL) {
        GamePadInterface->SetVibration(0, 255);
    } else if (keyid == Xbox360KEY_SELECT && GamePadInterface != NULL && GamePadInterface->SetVibration != NULL) {
        GamePadInterface->SetVibration(255, 0);
    }
}

void shou_update(int16_t out[4])
{
    float throttle;
    float steer;
    float left_target;
    float right_target;
    float delta_left;
    float delta_right;

    if (GamePadInterface == NULL || gamepad_inser_flag == 0U) {
        shou_reset_outputs(out);
        return;
    }

    shou_print_tick++;
    if (shou_print_tick >= SHOU_PRINT_DIV) {
        shou_print_tick = 0U;
        printf("LX=%3u LY=%3u RX=%3u RY=%3u\r\n",
               GamePadInterface->LX,
               GamePadInterface->LY,
               GamePadInterface->RX,
               GamePadInterface->RY);
    }

    throttle = shou_axis_signed(GamePadInterface->LY, 0U);
    steer = shou_axis_signed(GamePadInterface->LX, 0U) * SHOU_TURN_GAIN;

    left_target = shou_clampf(throttle + steer, -1.0f, 1.0f) * SHOU_MAX_CURRENT;
    right_target = shou_clampf(throttle - steer, -1.0f, 1.0f) * SHOU_MAX_CURRENT;

    delta_left = shou_clampf(left_target - shou_left_current, -SHOU_RAMP_STEP, SHOU_RAMP_STEP);
    delta_right = shou_clampf(right_target - shou_right_current, -SHOU_RAMP_STEP, SHOU_RAMP_STEP);

    shou_left_current += delta_left;
    shou_right_current += delta_right;

    out[0] = (int16_t)(-shou_right_current);
    out[1] = (int16_t)( shou_left_current);
    out[2] = (int16_t)(-shou_right_current);
    out[3] = (int16_t)( shou_left_current);
}
