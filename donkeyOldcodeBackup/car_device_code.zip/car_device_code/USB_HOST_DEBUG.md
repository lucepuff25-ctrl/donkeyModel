# STM32 USB Host Debug Notes

## 1. 背景

本工程使用 `STM32F427` 的 `USB OTG FS Host` 直接读取 USB 手柄接收器，不再通过上位机转发。

相关工程目录：

- `E:\F411\2026_MOTO`

主要涉及文件：

- `Core\Src\main.c`
- `SHOU\shou_control.c`
- `SHOU\shou_control.h`
- `SHOU\usbh_hid_GamePad.c`
- `SHOU\usbh_conf.c`
- `2026_MOTO.ioc`

---

## 2. 问题一：USB 能检测到设备，但一直初始化不过去

### 现象

串口反复输出类似：

```text
Gamepad detected, waiting for initialization...
USB port reset completed
```

但没有继续出现：

```text
USB device descriptor read ok
VID=...
PID=...
```

### 根因

USB FS 时钟配置错误。

原工程配置：

- `HSE = 12MHz`
- `PLLM = 6`
- `PLLN = 168`
- `PLLQ = 4`

算出来的 USB 时钟是：

```text
12 / 6 * 168 / 4 = 84 MHz
```

而 `USB FS` 必须是：

```text
48 MHz
```

### 修复方法

把 `PLLQ` 改为 `7`。

修改位置：

- `Core\Src\main.c`
- `2026_MOTO.ioc`

修复后时钟为：

```text
12 / 6 * 168 / 7 = 48 MHz
```

### 修复后应看到的日志

```text
USB device descriptor read ok
VID=0x045E PID=0x028E
Xbox360 gamepad recognized
Gamepad class init ok
Gamepad initialization passed
```

---

## 3. 问题二：枚举成功，但摇杆值一直是 127

### 现象

串口已经能输出：

```text
VID=0x045E PID=0x028E
Gamepad initialization passed
LX=127 LY=127 RX=127 RY=127
```

但无论怎么拨动摇杆，值都不变化。

### 排查过程

先排除了以下问题：

- USB 接口枚举失败
- VID/PID 不匹配
- 接口选错
- 端点选错

最终确认当前设备信息为：

- Interface `0`
- IN Endpoint `0x81`
- OUT Endpoint `0x02`
- Packet Size `64`

这些是正常的。

### 真正根因

`USB Host` 轮询频率太低。

原逻辑里：

- `MX_USB_HOST_Process()` 在 `shou_update()` 中调用
- `main()` 主循环最后有 `HAL_Delay(10)`

这导致 USB Host 状态机只有大约 `10ms` 才跑一次。

对手柄这类 `HID interrupt IN` 设备来说，这个频率太低，结果是：

- 已经进入 `GET_DATA`
- 但还没来得及稳定进入 `POLL -> URB_DONE -> 解码`
- 下一轮又重新发起提交

表现出来就是：

- 设备初始化成功
- 但收不到稳定的输入报告
- 摇杆值一直保持默认中位 `127`

### 修复方法

把 USB Host 轮询从 `10ms` 控制循环里拆出来：

- `shou_poll()`：高频调用 `MX_USB_HOST_Process()`
- `shou_update()`：仍然保持 `10ms` 一次，负责手柄映射和电机输出

修改位置：

- `SHOU\shou_control.h`
- `SHOU\shou_control.c`
- `Core\Src\main.c`

### 修复后的逻辑

- USB Host：高频轮询
- 电机控制：10ms 更新一次

这样既不会影响控制节拍，也能保证 USB 输入报告被正常读取。

---

## 4. 问题三：前后方向反了

### 现象

- 左右拨动摇杆正常
- 前推时四个轮子向后
- 后拉时四个轮子向前

### 根因

纵轴 `LY` 在映射时做了反向处理：

```c
throttle = shou_axis_signed(GamePadInterface->LY, 1U);
```

### 修复方法

改为：

```c
throttle = shou_axis_signed(GamePadInterface->LY, 0U);
```

修改位置：

- `SHOU\shou_control.c`

---

## 5. 当前最终结果

当前状态：

- USB 手柄接收器可被 STM32 Host 正常枚举
- 可以持续读取摇杆数据
- 串口已简化为只输出：

```text
LX=... LY=... RX=... RY=...
```

- 前后方向已修正

---

## 6. 下次再遇到 USB 问题，优先按这个顺序检查

### 第一步：先看 USB 时钟

确认是否为 `48MHz`：

- `HSE`
- `PLLM`
- `PLLN`
- `PLLQ`

只要不是 `48MHz`，USB FS 很容易枚举失败。

### 第二步：看是否能读到设备描述符

如果一直卡在 reset，不继续读设备描述符，优先怀疑：

- USB 时钟
- D+/D- 接线
- 5V 供电
- GND 共地

### 第三步：看是否已经识别到正确的接口和端点

重点确认：

- Interface 编号
- IN Endpoint
- OUT Endpoint
- Packet Size

### 第四步：如果枚举成功但数据不更新

优先怀疑：

- USB Host 轮询频率太低
- 主循环 `delay` 太大
- HID 状态机没有足够频率进入 `POLL`

### 第五步：如果值会变，但方向不对

这通常已经不是 USB 问题，而是映射问题：

- `LY` 是否反向
- `LX` 是否反向
- 左右轮输出符号是否相反

---

## 7. 本次关键结论

这次不是“USB Host 驱动没打上”。

真正的问题分两段：

1. USB FS 时钟错误，导致最开始枚举失败
2. USB Host 轮询频率过低，导致枚举成功后拿不到稳定输入数据

修完这两处之后，USB 手柄读取恢复正常。
