/**
 * @file    protocol.c
 * @brief   UART protocol parser + differential steering mixer + ramp limiter
 */

#include "protocol.h"
#include "motor_can.h"
#include "pid.h"

/* ---- Frame parser state machine ---- */
typedef enum { WAIT_HEADER, WAIT_SPEED, WAIT_ANGLE, WAIT_TAIL } parse_state_t;

static UART_HandleTypeDef *g_huart;
static uint8_t  rx_byte;          /* single-byte DMA/IT buffer */
static parse_state_t state = WAIT_HEADER;

/* Latest received command (written by ISR, read by update) */
static volatile uint8_t cmd_speed = 0x00;
static volatile uint8_t cmd_angle = 0x80;
static volatile uint8_t cmd_valid = 0;

static pid_t speed_pid[4];
static uint8_t speed_pid_ready = 0U;

/* ------------------------------------------------------------------ */

/**
 * @brief  Start single-byte interrupt reception.
 */
void protocol_init(UART_HandleTypeDef *huart)
{
    g_huart = huart;
    if (speed_pid_ready == 0U)
    {
        pid_init(&speed_pid[0], 3.0f, 0.05f, 0.0f, PROTO_MAX_CURRENT, 2000.0f, 10.0f);
        pid_init(&speed_pid[1], 3.0f, 0.05f, 0.0f, PROTO_MAX_CURRENT, 2000.0f, 10.0f);
        pid_init(&speed_pid[2], 3.0f, 0.05f, 0.0f, PROTO_MAX_CURRENT, 2000.0f, 10.0f);
        pid_init(&speed_pid[3], 3.0f, 0.05f, 0.0f, PROTO_MAX_CURRENT, 2000.0f, 10.0f);
        speed_pid_ready = 1U;
    }
    HAL_UART_Receive_IT(g_huart, &rx_byte, 1);
}

/**
 * @brief  Call from HAL_UART_RxCpltCallback.
 *         Parses one byte at a time using a state machine.
 */
void protocol_uart_rx_callback(UART_HandleTypeDef *huart)
{
    if (g_huart == NULL)
        return;

    if (huart->Instance != g_huart->Instance)
        return;

    static uint8_t s_speed, s_angle;

    switch (state)
    {
        case WAIT_HEADER:
            if (rx_byte == 0xAA) state = WAIT_SPEED;
            break;

        case WAIT_SPEED:
            s_speed = rx_byte;
            state   = WAIT_ANGLE;
            break;

        case WAIT_ANGLE:
            s_angle = rx_byte;
            state   = WAIT_TAIL;
            break;

        case WAIT_TAIL:
            if (rx_byte == 0xFF)
            {
                cmd_speed = s_speed;
                cmd_angle = s_angle;
                cmd_valid = 1;
            }
            /* reset regardless — re-sync on next header */
            state = WAIT_HEADER;
            break;
    }

    /* Re-arm single-byte reception */
    HAL_UART_Receive_IT(g_huart, &rx_byte, 1);
}

/* ------------------------------------------------------------------ */

/**
 * @brief  Differential steering mixer + ramp limiter.
 *         Call every 10ms.
 *
 * Mixing rule (matches motor layout):
 *   Left turn  (angle_norm < 0): right = speed,  left = speed*(1 + 2*angle_norm)
 *   Right turn (angle_norm > 0): left  = speed,  right = speed*(1 - 2*angle_norm)
 *   Straight   (angle_norm = 0): both sides = speed
 *
 * angle_norm: -1.0=max left  0=straight  +1.0=max right
 */
void protocol_update(int16_t out[4])
{
    /* Snapshot volatile fields */
    uint8_t spd = cmd_speed;
    uint8_t ang = cmd_angle;

    /* Normalise */
    float speed_norm = spd / 255.0f;              /* 0.0 ~ 1.0   */
    float angle_norm = (ang - 128) / 128.0f;      /* -1.0 ~ +1.0 */

    float right_fwd, left_fwd;

    if (angle_norm <= 0.0f)
    {
        /* Straight or left turn: right stays full, left scales down/reverses */
        right_fwd = speed_norm;
        left_fwd  = speed_norm * (1.0f + 2.0f * angle_norm);
    }
    else
    {
        /* Right turn: left stays full, right scales down/reverses */
        left_fwd  = speed_norm;
        right_fwd = speed_norm * (1.0f - 2.0f * angle_norm);
    }

    /* Clamp to [-1, 1] */
    if (right_fwd >  1.0f) right_fwd =  1.0f;
    if (right_fwd < -1.0f) right_fwd = -1.0f;
    if (left_fwd  >  1.0f) left_fwd  =  1.0f;
    if (left_fwd  < -1.0f) left_fwd  = -1.0f;

    /* Convert protocol command to wheel target RPM, then close the loop with PID. */
    out[0] = (int16_t)pid_calculate(&speed_pid[0], -right_fwd * PROTO_MAX_RPM, (float)motor_data[0].speed_rpm);
    out[1] = (int16_t)pid_calculate(&speed_pid[1],  left_fwd  * PROTO_MAX_RPM, (float)motor_data[1].speed_rpm);
    out[2] = (int16_t)pid_calculate(&speed_pid[2], -right_fwd * PROTO_MAX_RPM, (float)motor_data[2].speed_rpm);
    out[3] = (int16_t)pid_calculate(&speed_pid[3],  left_fwd  * PROTO_MAX_RPM, (float)motor_data[3].speed_rpm);
}
