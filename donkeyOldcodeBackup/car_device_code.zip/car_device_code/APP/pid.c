/**
 * @file    pid.c
 * @brief   位置式PID控制器实现
 */

#include "pid.h"

#define ABS(x)  ((x) >= 0.0f ? (x) : -(x))

/**
 * @brief  初始化PID参数，清空所有状态量
 */
void pid_init(pid_t *pid,
              float kp, float ki, float kd,
              float max_output,
              float integral_limit,
              float deadband)
{
    pid->kp             = kp;
    pid->ki             = ki;
    pid->kd             = kd;
    pid->max_output     = max_output;
    pid->integral_limit = integral_limit;
    pid->deadband       = deadband;

    pid->target  = 0.0f;
    pid->measure = 0.0f;
    pid->err     = 0.0f;
    pid->last_err= 0.0f;
    pid->pout    = 0.0f;
    pid->iout    = 0.0f;
    pid->dout    = 0.0f;
    pid->output  = 0.0f;
}

/**
 * @brief  PID计算
 * @return 本次输出值
 */
float pid_calculate(pid_t *pid, float target, float measure)
{
    pid->target   = target;
    pid->measure  = measure;
    pid->last_err = pid->err;
    pid->err      = pid->target - pid->measure;

    /* 死区判断：误差在死区内直接返回上次输出 */
    if (ABS(pid->err) < pid->deadband)
        return pid->output;

    pid->pout  = pid->kp * pid->err;
    pid->iout += pid->ki * pid->err;
    pid->dout  = pid->kd * (pid->err - pid->last_err);

    /* 积分限幅 */
    if      (pid->iout >  pid->integral_limit) pid->iout =  pid->integral_limit;
    else if (pid->iout < -pid->integral_limit) pid->iout = -pid->integral_limit;

    pid->output = pid->pout + pid->iout + pid->dout;

    /* 输出限幅 */
    if      (pid->output >  pid->max_output) pid->output =  pid->max_output;
    else if (pid->output < -pid->max_output) pid->output = -pid->max_output;

    return pid->output;
}

/**
 * @brief  重置PID内部状态（误差/积分/输出清零）
 */
void pid_reset(pid_t *pid)
{
    pid->err      = 0.0f;
    pid->last_err = 0.0f;
    pid->pout     = 0.0f;
    pid->iout     = 0.0f;
    pid->dout     = 0.0f;
    pid->output   = 0.0f;
}
