/**
 * @file    motor_can.h
 * @brief   大疆M2006电机CAN驱动（新版HAL API）
 *
 * 硬件连接：4个M2006电调通过汇流板合成一路CAN接STM32F411
 * 电机ID：0x201~0x204，控制帧ID：0x200
 */

#ifndef __MOTOR_CAN_H
#define __MOTOR_CAN_H

#include "stm32f4xx_hal.h"
#include <stdint.h>

/* ---- M2006 CAN 消息ID ---- */
#define CAN_M2006_CTRL_ID   0x200U   /* 发送控制电流的帧ID */
#define CAN_M2006_ID_1      0x201U   /* 电机1反馈ID */
#define CAN_M2006_ID_2      0x202U   /* 电机2反馈ID */
#define CAN_M2006_ID_3      0x203U   /* 电机3反馈ID */
#define CAN_M2006_ID_4      0x204U   /* 电机4反馈ID */

#define MOTOR_COUNT         4        /* 电机数量 */

/* ---- 电机反馈数据结构体 ---- */
typedef struct {
    int16_t  speed_rpm;      /* 转速，单位 RPM */
    float    real_current;   /* 实际电流，单位 A */
    uint8_t  hall;           /* 霍尔传感器值 */
    uint16_t angle;          /* 当前绝对角度 [0, 8191] */
    uint16_t last_angle;     /* 上一次角度（用于计圈） */
    uint16_t offset_angle;   /* 上电时的初始偏移角度 */
    int32_t  round_cnt;      /* 累计圈数 */
    int32_t  total_angle;    /* 相对上电零点的累计总角度 */
} motor_measure_t;

/* ---- 全局电机数据数组（下标0~3对应电机1~4）---- */
extern motor_measure_t motor_data[MOTOR_COUNT];

/* ---- 函数接口 ---- */

/**
 * @brief  初始化CAN滤波器，接收所有电机反馈帧
 * @param  hcan  CAN句柄（&hcan1）
 */
void motor_can_filter_init(CAN_HandleTypeDef *hcan);

/**
 * @brief  启动CAN外设并使能FIFO0接收中断
 * @param  hcan  CAN句柄（&hcan1）
 */
void motor_can_start(CAN_HandleTypeDef *hcan);

/**
 * @brief  CAN接收回调处理，在HAL_CAN_RxFifo0MsgPendingCallback中调用
 * @param  hcan  CAN句柄
 */
void motor_can_rx_callback(CAN_HandleTypeDef *hcan);

/**
 * @brief  向4个M2006发送电流控制指令
 * @param  hcan       CAN句柄
 * @param  iq1~iq4    各电机目标电流（范围 -10000 ~ +10000）
 */
HAL_StatusTypeDef motor_set_current(CAN_HandleTypeDef *hcan,
                                    int16_t iq1, int16_t iq2,
                                    int16_t iq3, int16_t iq4);

#endif /* __MOTOR_CAN_H */
