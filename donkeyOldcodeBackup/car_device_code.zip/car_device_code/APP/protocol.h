/**
 * @file    protocol.h
 * @brief   UART protocol parser + motor mixing + ramp limiter
 *
 * Frame format: 0xAA | speed(0x00~0xFF) | angle(0x00~0xFF) | 0xFF
 * Speed: 0x00=stop  0xFF=max forward
 * Angle: 0x00=max left  0x80=straight  0xFF=max right
 */

#ifndef __PROTOCOL_H
#define __PROTOCOL_H

#include "stm32f4xx_hal.h"
#include <stdint.h>

/* 0xFF speed command maps to this wheel target speed in RPM. */
#define PROTO_MAX_RPM       5000.0f

/* Max current sent to motors (tune this to limit top speed) */
#define PROTO_MAX_CURRENT   5000

/* Max current change per 10ms cycle.
 * 5000/RAMP_STEP cycles to go from stop to full speed.
 * e.g. RAMP_STEP=200 -> 250ms from 0 to full, ~500ms full-fwd to full-rev */
#define PROTO_RAMP_STEP     200

void protocol_init(UART_HandleTypeDef *huart);
void protocol_uart_rx_callback(UART_HandleTypeDef *huart);

/**
 * @brief  Call this every 10ms in the main loop.
 *         Applies ramp limiter and writes final values to out[].
 * @param  out  int16_t[4]: {iq1_RR, iq2_LR, iq3_RF, iq4_LF}
 */
void protocol_update(int16_t out[4]);

#endif /* __PROTOCOL_H */
