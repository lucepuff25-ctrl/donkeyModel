/**
 * @file    motor_can.c
 * @brief   大疆M2006电机CAN驱动实现（新版HAL API）
 *
 * 注意：使用新版HAL CAN API（HAL_CAN_AddTxMessage / HAL_CAN_GetRxMessage）
 *       不再使用旧版的 pTxMsg / pRxMsg 结构体指针
 */

#include "motor_can.h"

/* ---- 全局电机反馈数据 ---- */
motor_measure_t motor_data[MOTOR_COUNT] = {0};

/* ---- 内部函数声明 ---- */
static void motor_parse_feedback(motor_measure_t *m, uint8_t *data);

/* ------------------------------------------------------------------ */

/**
 * @brief  初始化CAN滤波器，接收0x201~0x204全部反馈帧
 *         STM32F411只有CAN1，FilterBank用0即可
 */
void motor_can_filter_init(CAN_HandleTypeDef *hcan)
{
    CAN_FilterTypeDef filter = {0};

    filter.FilterBank           = 0;
    filter.FilterMode           = CAN_FILTERMODE_IDMASK;
    filter.FilterScale          = CAN_FILTERSCALE_32BIT;
    filter.FilterIdHigh         = 0x0000;
    filter.FilterIdLow          = 0x0000;
    filter.FilterMaskIdHigh     = 0x0000;  /* 掩码全0 = 接收所有ID */
    filter.FilterMaskIdLow      = 0x0000;
    filter.FilterFIFOAssignment = CAN_RX_FIFO0;
    filter.FilterActivation     = ENABLE;

    HAL_CAN_ConfigFilter(hcan, &filter);
}

/**
 * @brief  启动CAN并使能FIFO0消息挂起中断
 */
void motor_can_start(CAN_HandleTypeDef *hcan)
{
    HAL_CAN_Start(hcan);
    HAL_CAN_ActivateNotification(hcan, CAN_IT_RX_FIFO0_MSG_PENDING);
}

/* ------------------------------------------------------------------ */

/**
 * @brief  解析M2006反馈数据帧（8字节）
 *
 * 帧格式（大疆协议）：
 *   Byte[0:1] = 转子机械角度  [0, 8191]
 *   Byte[2:3] = 转速           RPM
 *   Byte[4:5] = 实际转矩电流
 *   Byte[6]   = 霍尔传感器值
 */
static void motor_parse_feedback(motor_measure_t *m, uint8_t *data)
{
    m->last_angle = m->angle;
    m->angle      = (uint16_t)(data[0] << 8 | data[1]);
    m->speed_rpm  = (int16_t) (data[2] << 8 | data[3]);
    /* 实际电流换算：满量程16384对应5A */
    m->real_current = (float)(data[4] << 8 | data[5]) * 5.0f / 16384.0f;
    m->hall       = data[6];

    /* 计算圈数（角度跳变超过半圈判断方向） */
    int32_t delta = (int32_t)m->angle - (int32_t)m->last_angle;
    if      (delta >  4096) m->round_cnt--;
    else if (delta < -4096) m->round_cnt++;

    m->total_angle = m->round_cnt * 8192 + m->angle - m->offset_angle;
}

/**
 * @brief  CAN接收回调入口，在 HAL_CAN_RxFifo0MsgPendingCallback 中调用
 */
void motor_can_rx_callback(CAN_HandleTypeDef *hcan)
{
    CAN_RxHeaderTypeDef rx_header;
    uint8_t rx_data[8];

    if (HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &rx_header, rx_data) != HAL_OK)
        return;

    /* 判断是否是M2006反馈帧 */
    if (rx_header.StdId >= CAN_M2006_ID_1 && rx_header.StdId <= CAN_M2006_ID_4) {
        uint8_t idx = (uint8_t)(rx_header.StdId - CAN_M2006_ID_1);
        motor_parse_feedback(&motor_data[idx], rx_data);
    }
}

/* ------------------------------------------------------------------ */

/**
 * @brief  向4个M2006发送电流控制指令
 *
 * 发送帧格式（ID=0x200，DLC=8）：
 *   Byte[0:1] = 电机1电流（int16，大端）
 *   Byte[2:3] = 电机2电流
 *   Byte[4:5] = 电机3电流
 *   Byte[6:7] = 电机4电流
 *
 * @param  iq1~iq4  目标电流值，范围 -10000 ~ +10000
 */
HAL_StatusTypeDef motor_set_current(CAN_HandleTypeDef *hcan,
                                    int16_t iq1, int16_t iq2,
                                    int16_t iq3, int16_t iq4)
{
    CAN_TxHeaderTypeDef tx_header;
    uint8_t  tx_data[8];
    uint32_t tx_mailbox;

    tx_header.StdId              = CAN_M2006_CTRL_ID;
    tx_header.IDE                = CAN_ID_STD;
    tx_header.RTR                = CAN_RTR_DATA;
    tx_header.DLC                = 8;
    tx_header.TransmitGlobalTime = DISABLE;

    tx_data[0] = (uint8_t)(iq1 >> 8);
    tx_data[1] = (uint8_t)(iq1);
    tx_data[2] = (uint8_t)(iq2 >> 8);
    tx_data[3] = (uint8_t)(iq2);
    tx_data[4] = (uint8_t)(iq3 >> 8);
    tx_data[5] = (uint8_t)(iq3);
    tx_data[6] = (uint8_t)(iq4 >> 8);
    tx_data[7] = (uint8_t)(iq4);

    return HAL_CAN_AddTxMessage(hcan, &tx_header, tx_data, &tx_mailbox);
}
