/**
 * @file    pid.h
 * @brief   增量式/位置式PID控制器
 */

#ifndef __PID_H
#define __PID_H

#include <stdint.h>

typedef struct {
    float kp;             /* 比例系数 */
    float ki;             /* 积分系数 */
    float kd;             /* 微分系数 */

    float target;         /* 目标值 */
    float measure;        /* 测量值 */
    float err;            /* 当前误差 */
    float last_err;       /* 上次误差 */

    float pout;           /* P输出分量 */
    float iout;           /* I输出分量（累积） */
    float dout;           /* D输出分量 */
    float output;         /* 最终输出 */

    float max_output;     /* 输出限幅 */
    float integral_limit; /* 积分限幅 */
    float deadband;       /* 死区（误差小于此值不计算） */
} pid_t;

/**
 * @brief  初始化PID参数
 */
void pid_init(pid_t *pid,
              float kp, float ki, float kd,
              float max_output,
              float integral_limit,
              float deadband);

/**
 * @brief  PID计算，返回输出值
 * @param  target   目标值
 * @param  measure  测量值
 */
float pid_calculate(pid_t *pid, float target, float measure);

/**
 * @brief  重置PID积分和误差（急停/换目标时调用）
 */
void pid_reset(pid_t *pid);

#endif /* __PID_H */
